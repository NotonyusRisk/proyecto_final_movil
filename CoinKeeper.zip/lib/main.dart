import 'package:coinkeeper/src/myApp.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());
