import 'package:coinkeeper/src/variableGlobal.dart';
import 'package:flutter/material.dart';

class CuartaRuta extends StatefulWidget {
  State<CuartaRuta> createState() => _CuartaRutaState();
}

class _CuartaRutaState extends State<CuartaRuta> {
  final TextEditingController _numeros = TextEditingController();
  static String texto = "";
  void _CalcularGato(double total, int personas) {
    double x = total / personas;

    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      texto = "$x";
    });
  }

  @override
  Widget build(BuildContext context) {
    double total = GastosManager().total;
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 179, 248, 196),
        appBar: AppBar(
          elevation: 1,
          backgroundColor: Color.fromARGB(255, 179, 248, 196),
          centerTitle: true,
          title: Text(
            "Reparto",
            style: TextStyle(
                fontFamily: 'Jost',
                fontSize: 35,
                color: Color.fromARGB(255, 2, 70, 4),
                fontWeight: FontWeight.w900),
          ),
        ),
        body: Center(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40, left: 10, right: 10),
                child: Center(
                  child: Text(
                    "CoinKeeper te facilitará salidas con las personas que te gusta disfrutar.",
                    style: TextStyle(
                      fontFamily: 'Jost',
                      fontSize: 20,
                      color: Color.fromARGB(255, 2, 70, 4),
                      fontWeight: FontWeight.w100,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Container(
                  margin: EdgeInsets.only(top: 20, left: 40, right: 40),
                  child: _buildTable()),
              Container(
                margin: EdgeInsets.only(bottom: 20),
                child: Text("Ingrese el numero de personas",
                    style: TextStyle(fontFamily: 'Jost', fontSize: 20)),
              ),
              Container(
                alignment: AlignmentDirectional.center,
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.only(left: 20),
                width: 280,
                height: 70,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 179, 248, 196),
                  border: Border.all(
                      color: Color.fromARGB(255, 179, 248, 196), width: 1),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    new BoxShadow(
                      color: Colors.black,
                      offset: new Offset(0.0, 7.0),
                      blurRadius: 7.0,
                    )
                  ],
                ),
                child: InputDecorator(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                  ),
                  child: TextField(
                      controller: _numeros,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        labelText: '',
                        labelStyle: TextStyle(fontSize: 30),
                      )),
                ),
              ),
              Container(
                width: 100,
                height: 30,
                child: ElevatedButton(
                  onPressed: () {
                    if (_numeros.text == "") {
                    } else {
                      _CalcularGato(total, int.tryParse(_numeros.text) ?? 0);
                    }
                  },
                  child: Text('Calcular'),
                  style: ButtonStyle(
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Color(0xff16753e)),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                  child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(
                        top: 40, left: 90, right: 10, bottom: 7),
                    child: Text(
                      'Total por persona:',
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w900),
                    ),
                  ),
                  Container(
                    alignment: AlignmentDirectional.center,
                    margin: EdgeInsets.only(left: 140, right: 10),
                    padding: EdgeInsets.only(left: 20),
                    width: 120,
                    height: 40,
                    child: Text(texto),
                    decoration: BoxDecoration(
                      color: Color(0xff16753e),
                      border: Border.all(color: Color(0xff16753e), width: 1),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        new BoxShadow(
                          color: Color(0xffffffff),
                          offset: new Offset(0.0, 7.0),
                          blurRadius: 7.0,
                        )
                      ],
                    ),
                  ),
                ],
              )),
              Container(
                margin: EdgeInsets.only(top: 50),
                child: Text(
                  "By DGR",
                  style: TextStyle(
                    fontFamily: 'Jost',
                    fontSize: 20,
                    color: Color.fromARGB(255, 2, 70, 4),
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}

Widget _buildTable() {
  double total = GastosManager().total;
  return DataTable(
    columns: <DataColumn>[
      const DataColumn(
          label: Text(
            "Total",
            style: TextStyle(fontSize: 20),
          ),
          tooltip: 'Total'),
      DataColumn(
          label: Text(
            "$total",
            style: TextStyle(fontSize: 20),
          ),
          tooltip: '000000',
          numeric: true),
    ],
    rows: <DataRow>[
      DataRow(
        cells: <DataCell>[
          DataCell(Text('')),
          DataCell(Text('')),
        ],
      ),
    ],
  );
}
