class Gasto {
  String nombre;
  int monto;

  Gasto(this.nombre, this.monto);
}
