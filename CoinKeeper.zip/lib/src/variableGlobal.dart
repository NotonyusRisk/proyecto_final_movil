import 'package:coinkeeper/src/gastos.dart';

class GastosManager {
  static final GastosManager _instance = GastosManager._internal();

  factory GastosManager() {
    return _instance;
  }

  GastosManager._internal();

  List<Gasto> _gastos = [];
  double _total = 0.0;
  double _resultante = 0.0;
  double get total => _total;
  List<Gasto> get gastos => _gastos;
  double get resultante => _resultante;

  void agregarGasto(Gasto gasto) {
    _gastos.add(gasto);
    _total += gasto.monto;
  }

  void eliminarGasto(List<Gasto> list) {
    list.clear();
    _total = 0.0;
  }
}
