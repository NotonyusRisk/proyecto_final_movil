import 'package:coinkeeper/src/variableGlobal.dart';
import 'package:flutter/material.dart';
import 'package:coinkeeper/src/repartir.dart';

import 'gastos.dart';

class TerceraRuta extends StatefulWidget {
  @override
  State<TerceraRuta> createState() => _TerceraRutaState();
}

class _TerceraRutaState extends State<TerceraRuta> {
  void _eliminarGasto(List<Gasto> list) {
    setState(() {
      GastosManager().eliminarGasto(list);
    });
  }

  Widget build(BuildContext context) {
    List<Gasto> gastos = GastosManager().gastos;
    double total = GastosManager().total;
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 179, 248, 196),
        appBar: AppBar(
          elevation: 1,
          backgroundColor: Color.fromARGB(255, 179, 248, 196),
          centerTitle: true,
          title: Text(
            "Registro",
            style: TextStyle(
                fontFamily: 'Jost',
                fontSize: 35,
                color: Color.fromARGB(255, 2, 70, 4),
                fontWeight: FontWeight.w900),
          ),
        ),
        body: Center(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40, left: 10, right: 10),
                child: Center(
                  child: Text(
                    "CoinKeeper registra con exito todos los gastos que realices.",
                    style: TextStyle(
                      fontFamily: 'Jost',
                      fontSize: 20,
                      color: Color.fromARGB(255, 2, 70, 4),
                      fontWeight: FontWeight.w100,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Container(
                alignment: AlignmentDirectional.bottomEnd,
                margin: EdgeInsets.only(top: 5, right: 20),
                child: IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    // Do something when the button is pressed
                    _eliminarGasto(gastos);
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 5, left: 30, right: 30),
                child: DataTable(
                  columns: [
                    DataColumn(label: Text('Nombre')),
                    DataColumn(label: Text('Monto')),
                  ],
                  rows: gastos
                      .map(
                        (gasto) => DataRow(
                          cells: [
                            DataCell(Text(gasto.nombre)),
                            DataCell(Text(gasto.monto.toString())),
                          ],
                        ),
                      )
                      .toList(),
                ),
              ),
              Container(
                  child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(
                        left: 90, right: 10, bottom: 7, top: 15),
                    child: Text(
                      'Total:',
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w900),
                    ),
                  ),
                  Container(
                    alignment: AlignmentDirectional.center,
                    margin: EdgeInsets.only(left: 140, right: 10),
                    padding: EdgeInsets.only(left: 20),
                    width: 120,
                    height: 40,
                    child: Text(" $total "),
                    decoration: BoxDecoration(
                      color: Color(0xff16753e),
                      border: Border.all(color: Color(0xff16753e), width: 1),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black,
                          offset: new Offset(0.0, 7.0),
                          blurRadius: 7.0,
                        )
                      ],
                    ),
                  ),
                ],
              )),
              Container(
                margin: EdgeInsets.only(top: 20),
                height: 70,
                width: 160,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (contxt) => CuartaRuta()),
                    ); // Acción a realizar cuando se presiona el botón
                  },
                  child: Text('Repartir',
                      style: TextStyle(
                        fontFamily: 'Jost',
                        fontSize: 20,
                      )),
                  style: ButtonStyle(
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Color(0xff16753e)),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  boxShadow: [
                    new BoxShadow(
                      color: Colors.black,
                      offset: new Offset(0.0, 5.0),
                      blurRadius: 9.0,
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 30),
                child: Text(
                  "By DGR",
                  style: TextStyle(
                    fontFamily: 'Jost',
                    fontSize: 20,
                    color: Color.fromARGB(255, 2, 70, 4),
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
