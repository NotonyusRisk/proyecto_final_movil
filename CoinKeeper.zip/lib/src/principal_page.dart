import 'package:coinkeeper/src/variableGlobal.dart';
import 'package:flutter/material.dart';
import 'package:coinkeeper/src/tercera_pagina.dart';

import 'gastos.dart';

class SegundaRuta extends StatefulWidget {
  const SegundaRuta({super.key});

  @override
  State<SegundaRuta> createState() => _SegundaRutaState();
}

class _SegundaRutaState extends State<SegundaRuta> {
  final TextEditingController _info = TextEditingController();
  final TextEditingController _monto = TextEditingController();

  void _agregarGasto(String info, int monto) {
    GastosManager().agregarGasto(Gasto(info, monto));
    _info.clear();
    _monto.clear();
    print("si funciona");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 179, 248, 196),
        appBar: AppBar(
          elevation: 1,
          backgroundColor: Color.fromARGB(255, 179, 248, 196),
          centerTitle: true,
          title: Text(
            "Home",
            style: TextStyle(
                fontFamily: 'Jost',
                fontSize: 35,
                color: Color.fromARGB(255, 2, 70, 4),
                fontWeight: FontWeight.w900),
          ),
        ),
        body: Center(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40),
                child: Center(
                  child: Text(
                    "Hola, CoinKeeper te invita a registrar tus gastos aquí.",
                    style: TextStyle(
                      fontFamily: 'Jost',
                      fontSize: 20,
                      color: Color.fromARGB(255, 2, 70, 4),
                      fontWeight: FontWeight.w100,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Container(
                child: Row(
                  children: [
                    Container(
                      alignment: AlignmentDirectional.bottomStart,
                      margin: EdgeInsets.only(top: 40, left: 10),
                      child: Text(
                        "¿En que fue tu gasto?",
                        style: TextStyle(
                          fontFamily: 'Jost',
                          fontSize: 20,
                          color: Color.fromARGB(255, 2, 70, 4),
                          fontWeight: FontWeight.w100,
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                alignment: AlignmentDirectional.center,
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.only(left: 20),
                width: 280,
                height: 70,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 179, 248, 196),
                  border: Border.all(
                      color: Color.fromARGB(255, 179, 248, 196), width: 1),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    new BoxShadow(
                      color: Colors.black,
                      offset: new Offset(0.0, 7.0),
                      blurRadius: 7.0,
                    )
                  ],
                ),
                child: InputDecorator(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                  ),
                  child: TextField(
                      controller: _info,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Insertar aquí',
                        hintStyle: TextStyle(
                            fontSize: 30, color: Color.fromARGB(255, 2, 70, 4)),
                      )),
                ),
              ),
              Container(
                alignment: AlignmentDirectional.bottomStart,
                margin: EdgeInsets.only(top: 20, left: 10),
                child: Text(
                  "Ingresa el gasto",
                  style: TextStyle(
                    fontFamily: 'Jost',
                    fontSize: 20,
                    color: Color.fromARGB(255, 2, 70, 4),
                    fontWeight: FontWeight.w100,
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              Container(
                alignment: AlignmentDirectional.center,
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.only(left: 20),
                width: 280,
                height: 70,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 179, 248, 196),
                  border: Border.all(
                      color: Color.fromARGB(255, 179, 248, 196), width: 1),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    new BoxShadow(
                      color: Colors.black,
                      offset: new Offset(0.0, 7.0),
                      blurRadius: 7.0,
                    )
                  ],
                ),
                child: InputDecorator(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                  ),
                  child: TextField(
                      controller: _monto,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Insertar aquí',
                        hintStyle: TextStyle(
                            fontSize: 30, color: Color.fromARGB(255, 2, 70, 4)),
                      )),
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                height: 70,
                width: 160,
                child: ElevatedButton(
                  onPressed: () {
                    if (_info.text == "" || _monto.text == "") {
                      print("No hay nada");
                    } else {
                      _agregarGasto(_info.text, int.tryParse(_monto.text) ?? 0);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (contxt) =>
                                TerceraRuta()), // Nombre de la siguiente ruta
                      );
                    } // Acción a realizar cuando se presiona el botón
                  },
                  child: Text('Agregar',
                      style: TextStyle(
                        fontFamily: 'Jost',
                        fontSize: 20,
                      )),
                  style: ButtonStyle(
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Color(0xff16753e)),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  boxShadow: [
                    new BoxShadow(
                      color: Colors.black,
                      offset: new Offset(0.0, 5.0),
                      blurRadius: 9.0,
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 25),
                child: Text(
                  "By DGR",
                  style: TextStyle(
                    fontFamily: 'Jost',
                    fontSize: 20,
                    color: Color.fromARGB(255, 2, 70, 4),
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
