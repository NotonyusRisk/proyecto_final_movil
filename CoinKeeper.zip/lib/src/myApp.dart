import 'package:coinkeeper/src/principal_page.dart';
import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 179, 248, 196),
      body: Center(
          child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 100),
            // Ancho deseado del Container
            //
            width: 300,
            height: 300.0, // Altura deseada del Container
            decoration: BoxDecoration(
              image: DecorationImage(
                image: const AssetImage(
                    'assets/img/logo_keeper-removebg-preview(1).png'), // Ruta de la imagen en el proyecto
                // Ajusta la imagen al tamaño del Container
              ),
            ),
          ),
          Container(
            child: const Text(
              "CoinKeeper",
              style: TextStyle(
                  fontSize: 40,
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.w200),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            height: 80,
            width: 180,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xff366637),
                elevation: 4.0, // Establece la elevación del botón
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                      20.0), // Establece el radio de las esquinas del botón
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (contxt) =>
                          SegundaRuta()), // Nombre de la siguiente ruta
                );
              },
              child: Text('Iniciar',
                  style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w100)), // Texto del botón
            ),
            decoration: BoxDecoration(
              boxShadow: [
                new BoxShadow(
                  color: Colors.black,
                  offset: new Offset(0.0, 5.0),
                  blurRadius: 9.0,
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 50),
            child: Text(
              "By DGR",
              style: TextStyle(
                fontFamily: 'Jost',
                fontSize: 20,
                color: Color.fromARGB(255, 2, 70, 4),
              ),
            ),
          )
        ],
      )),
    );
  }
}
