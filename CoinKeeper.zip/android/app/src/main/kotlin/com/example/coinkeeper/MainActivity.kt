package com.example.coinkeeper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
